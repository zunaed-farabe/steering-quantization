# Steering under weight quantization

Split: **validation**. Config: `69e25e40ceca2e43`.

Synthetic smoke results validate plumbing only; real-model results require a GPU run.

| Precision | Source | Layer | Strength | Ambiguous acc. | Disambiguated acc. | Invalid |
|---|---|---:|---:|---:|---:|---:|
| bf16 | none | None | 0.0 | 0.984 | 0.660 | 0.000 |
| bf16 | prompt | None | 0.0 | 0.990 | 0.729 | 0.003 |
| bf16 | random | 20 | 0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 20 | -0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 8 | 0.1 | 0.984 | 0.656 | 0.000 |
| bf16 | random | 8 | -0.15 | 0.984 | 0.656 | 0.000 |
| bf16 | random | 13 | 0.6 | 0.992 | 0.642 | 0.000 |
| bf16 | random | 13 | 0.15 | 0.985 | 0.655 | 0.000 |
| bf16 | random | 13 | -0.3 | 0.982 | 0.650 | 0.000 |
| bf16 | random | 8 | -0.6 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 13 | 0.1 | 0.985 | 0.656 | 0.000 |
| bf16 | random | 20 | 0.3 | 0.982 | 0.658 | 0.000 |
| bf16 | random | 8 | -0.3 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 8 | 0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 20 | -0.3 | 0.984 | 0.650 | 0.001 |
| bf16 | random | 8 | 0.6 | 0.985 | 0.647 | 0.000 |
| bf16 | random | 20 | 0.6 | 0.976 | 0.658 | 0.000 |
| bf16 | random | 13 | 0.3 | 0.989 | 0.653 | 0.000 |
| bf16 | random | 8 | -0.1 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 13 | -0.15 | 0.984 | 0.661 | 0.000 |
| bf16 | random | 20 | -0.6 | 0.987 | 0.647 | 0.001 |
| bf16 | random | 20 | -0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 8 | 0.3 | 0.984 | 0.656 | 0.000 |
| bf16 | random | 13 | -0.1 | 0.984 | 0.661 | 0.000 |
| bf16 | random | 20 | 0.15 | 0.984 | 0.661 | 0.000 |
| bf16 | random | 13 | -0.6 | 0.982 | 0.639 | 0.000 |
| bf16 | reference | 13 | 0.15 | 0.984 | 0.655 | 0.000 |
| bf16 | reference | 8 | 0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 20 | 0.3 | 0.985 | 0.656 | 0.000 |
| bf16 | reference | 20 | -0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 8 | 0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 13 | 0.1 | 0.984 | 0.655 | 0.000 |
| bf16 | reference | 20 | 0.6 | 0.987 | 0.637 | 0.000 |
| bf16 | reference | 20 | 0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 13 | 0.3 | 0.987 | 0.650 | 0.000 |
| bf16 | reference | 8 | -0.1 | 0.984 | 0.655 | 0.000 |
| bf16 | reference | 20 | -0.6 | 0.987 | 0.642 | 0.000 |
| bf16 | reference | 13 | -0.6 | 0.969 | 0.645 | 0.000 |
| bf16 | reference | 8 | 0.6 | 0.985 | 0.658 | 0.000 |
| bf16 | reference | 13 | -0.1 | 0.984 | 0.656 | 0.000 |
| bf16 | reference | 8 | -0.6 | 0.984 | 0.656 | 0.000 |
| bf16 | reference | 8 | -0.3 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 13 | -0.3 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 8 | -0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 20 | 0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 20 | -0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 20 | -0.3 | 0.984 | 0.652 | 0.000 |
| bf16 | reference | 13 | -0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 13 | 0.6 | 0.995 | 0.605 | 0.000 |
| bf16 | reference | 8 | 0.3 | 0.985 | 0.660 | 0.000 |

Paired 95% intervals resample whole scenario groups. Multiple strengths are exploratory; no multiplicity correction or equivalence claim is made.
See analysis.json for bias denominators, group-pair results, answer transitions, and paired intervals. Missing bias targets reduce annotation coverage; unknown and invalid outputs remain explicit.
