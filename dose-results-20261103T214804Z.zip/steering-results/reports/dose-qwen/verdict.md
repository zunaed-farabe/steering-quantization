# Dose check: Qwen/Qwen2.5-7B-Instruct

**Verdict: FAIL** (0 of 24 settings passed; rule in docs/dose-finding.md)

Unsteered baseline: stereotyped answers 0.030, ambiguous accuracy 0.984, disambiguated accuracy 0.660, unnecessary unknown 0.266, invalid 0.000, truncated 0.000.

| Layer | Strength | Stereotyped | Reduction | Bias vector minus random (95% CI) | Answers changed (vector / random) | Limits broken | Pass |
|---:|---:|---:|---:|---|---:|---|---|
| 8 | -0.6 | 0.029 | +0.001 | +0.000 [-0.002, +0.002] | 9 / 5 | — | no |
| 8 | -0.3 | 0.028 | +0.002 | -0.002 [-0.005, +0.000] | 6 / 2 | — | no |
| 8 | -0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 1 / 2 | — | no |
| 8 | -0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 3 / 1 | — | no |
| 8 | +0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 2 / 2 | — | no |
| 8 | +0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 1 / 1 | — | no |
| 8 | +0.3 | 0.029 | +0.001 | -0.001 [-0.002, +0.000] | 5 / 4 | — | no |
| 8 | +0.6 | 0.029 | +0.001 | +0.001 [-0.002, +0.004] | 14 / 13 | — | no |
| 13 | -0.6 | 0.030 | +0.000 | +0.004 [-0.006, +0.017] | 43 / 34 | unnecessary_unknown | no |
| 13 | -0.3 | 0.028 | +0.002 | +0.000 [-0.005, +0.005] | 4 / 15 | — | no |
| 13 | -0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 1 / 1 | — | no |
| 13 | -0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 2 / 1 | — | no |
| 13 | +0.1 | 0.030 | +0.000 | +0.001 [+0.000, +0.002] | 3 / 3 | — | no |
| 13 | +0.15 | 0.030 | +0.000 | +0.001 [+0.000, +0.002] | 4 / 4 | — | no |
| 13 | +0.3 | 0.024 | +0.006 | -0.002 [-0.008, +0.004] | 21 / 13 | unnecessary_unknown | no |
| 13 | +0.6 | 0.015 | +0.015 | -0.004 [-0.011, +0.003] | 74 / 42 | disambig_accuracy, unnecessary_unknown | no |
| 20 | -0.6 | 0.023 | +0.007 | -0.004 [-0.011, +0.002] | 43 / 20 | unnecessary_unknown | no |
| 20 | -0.3 | 0.029 | +0.001 | +0.001 [-0.002, +0.004] | 19 / 10 | — | no |
| 20 | -0.15 | 0.029 | +0.001 | -0.001 [-0.002, +0.000] | 4 / 3 | — | no |
| 20 | -0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 2 / 2 | — | no |
| 20 | +0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 3 / 4 | — | no |
| 20 | +0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 4 / 8 | — | no |
| 20 | +0.3 | 0.029 | +0.001 | -0.001 [-0.004, +0.002] | 6 / 14 | — | no |
| 20 | +0.6 | 0.025 | +0.005 | -0.004 [-0.009, +0.000] | 28 / 29 | disambig_accuracy, unnecessary_unknown | no |

Validation only and exploratory: settings are not corrected for multiple comparisons, and there is one random direction per layer. A pass names a candidate for the full study, not a finding.
