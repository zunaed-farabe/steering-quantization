# Steering under weight quantization

Split: **validation**. Config: `c6ab5991d8a0e63b`.

Synthetic smoke results validate plumbing only; real-model results require a GPU run.

| Precision | Source | Layer | Strength | Ambiguous acc. | Disambiguated acc. | Invalid |
|---|---|---:|---:|---:|---:|---:|
| bf16 | none | None | 0.0 | 0.984 | 0.660 | 0.000 |
| bf16 | prompt | None | 0.0 | 0.990 | 0.729 | 0.003 |
| bf16 | random | 20 | -0.3 | 0.984 | 0.650 | 0.001 |
| bf16 | random | 8 | -0.15 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 13 | -0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 20 | 0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 20 | 0.3 | 0.982 | 0.660 | 0.000 |
| bf16 | random | 8 | 0.6 | 0.985 | 0.647 | 0.000 |
| bf16 | random | 8 | 0.15 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 8 | 0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 13 | -0.6 | 0.982 | 0.642 | 0.000 |
| bf16 | random | 20 | 0.6 | 0.976 | 0.658 | 0.000 |
| bf16 | random | 8 | -0.6 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 13 | 0.3 | 0.987 | 0.653 | 0.000 |
| bf16 | random | 20 | -0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | random | 8 | -0.3 | 0.984 | 0.656 | 0.000 |
| bf16 | random | 8 | 0.3 | 0.985 | 0.656 | 0.000 |
| bf16 | random | 20 | -0.15 | 0.984 | 0.656 | 0.000 |
| bf16 | random | 20 | -0.6 | 0.987 | 0.647 | 0.001 |
| bf16 | random | 8 | -0.1 | 0.984 | 0.658 | 0.000 |
| bf16 | random | 13 | 0.6 | 0.992 | 0.639 | 0.000 |
| bf16 | random | 13 | 0.1 | 0.985 | 0.658 | 0.000 |
| bf16 | random | 20 | 0.1 | 0.984 | 0.661 | 0.000 |
| bf16 | random | 13 | -0.3 | 0.982 | 0.653 | 0.000 |
| bf16 | random | 13 | -0.15 | 0.984 | 0.661 | 0.000 |
| bf16 | random | 13 | 0.15 | 0.985 | 0.655 | 0.000 |
| bf16 | reference | 20 | 0.1 | 0.985 | 0.656 | 0.000 |
| bf16 | reference | 13 | 0.6 | 0.987 | 0.632 | 0.000 |
| bf16 | reference | 13 | 0.15 | 0.984 | 0.656 | 0.000 |
| bf16 | reference | 13 | -0.1 | 0.984 | 0.658 | 0.000 |
| bf16 | reference | 8 | 0.6 | 0.982 | 0.660 | 0.000 |
| bf16 | reference | 20 | 0.3 | 0.987 | 0.632 | 0.000 |
| bf16 | reference | 13 | 0.3 | 0.984 | 0.655 | 0.000 |
| bf16 | reference | 13 | -0.6 | 0.982 | 0.676 | 0.000 |
| bf16 | reference | 13 | -0.3 | 0.985 | 0.660 | 0.000 |
| bf16 | reference | 8 | 0.3 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 8 | 0.15 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 13 | 0.1 | 0.984 | 0.655 | 0.000 |
| bf16 | reference | 8 | -0.15 | 0.984 | 0.656 | 0.000 |
| bf16 | reference | 8 | -0.3 | 0.984 | 0.648 | 0.000 |
| bf16 | reference | 20 | -0.6 | 0.966 | 0.669 | 0.000 |
| bf16 | reference | 20 | 0.6 | 0.992 | 0.611 | 0.000 |
| bf16 | reference | 20 | -0.1 | 0.981 | 0.663 | 0.000 |
| bf16 | reference | 20 | 0.15 | 0.987 | 0.650 | 0.000 |
| bf16 | reference | 13 | -0.15 | 0.984 | 0.656 | 0.000 |
| bf16 | reference | 20 | -0.15 | 0.981 | 0.668 | 0.000 |
| bf16 | reference | 8 | -0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 8 | -0.6 | 0.984 | 0.647 | 0.000 |
| bf16 | reference | 8 | 0.1 | 0.984 | 0.660 | 0.000 |
| bf16 | reference | 20 | -0.3 | 0.974 | 0.671 | 0.000 |

Paired 95% intervals resample whole scenario groups. Multiple strengths are exploratory; no multiplicity correction or equivalence claim is made.
See analysis.json for bias denominators, group-pair results, answer transitions, and paired intervals. Missing bias targets reduce annotation coverage; unknown and invalid outputs remain explicit.
