# Dose check: Qwen/Qwen2.5-7B-Instruct

**Verdict: FAIL** (0 of 24 settings passed; rule in docs/dose-finding.md)

Unsteered baseline: stereotyped answers 0.030, ambiguous accuracy 0.984, disambiguated accuracy 0.660, unnecessary unknown 0.266, invalid 0.000, truncated 0.000.

| Layer | Strength | Stereotyped | Reduction | Bias vector minus random (95% CI) | Answers changed (vector / random) | Limits broken | Pass |
|---:|---:|---:|---:|---|---:|---|---|
| 8 | -0.6 | 0.026 | +0.004 | -0.003 [-0.007, +0.000] | 21 / 6 | unnecessary_unknown | no |
| 8 | -0.3 | 0.029 | +0.001 | -0.001 [-0.002, +0.000] | 10 / 2 | — | no |
| 8 | -0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 2 / 2 | — | no |
| 8 | -0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 0 / 1 | — | no |
| 8 | +0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 0 / 2 | — | no |
| 8 | +0.15 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 0 / 1 | — | no |
| 8 | +0.3 | 0.030 | +0.000 | +0.001 [+0.000, +0.002] | 0 / 5 | — | no |
| 8 | +0.6 | 0.030 | +0.000 | +0.003 [+0.000, +0.007] | 3 / 17 | — | no |
| 13 | -0.6 | 0.021 | +0.009 | -0.006 [-0.021, +0.006] | 33 / 31 | — | no |
| 13 | -0.3 | 0.025 | +0.005 | -0.002 [-0.010, +0.004] | 14 / 13 | — | no |
| 13 | -0.15 | 0.029 | +0.001 | -0.001 [-0.002, +0.000] | 4 / 3 | — | no |
| 13 | -0.1 | 0.030 | +0.000 | +0.000 [+0.000, +0.000] | 1 / 2 | — | no |
| 13 | +0.1 | 0.030 | +0.000 | +0.001 [+0.000, +0.002] | 4 / 2 | — | no |
| 13 | +0.15 | 0.030 | +0.000 | +0.001 [+0.000, +0.002] | 7 / 4 | — | no |
| 13 | +0.3 | 0.027 | +0.003 | +0.001 [-0.004, +0.006] | 10 / 12 | — | no |
| 13 | +0.6 | 0.023 | +0.006 | +0.004 [-0.003, +0.010] | 36 / 40 | disambig_accuracy, unnecessary_unknown | no |
| 20 | -0.6 | 0.033 | -0.003 | +0.006 [-0.002, +0.016] | 27 / 21 | — | no |
| 20 | -0.3 | 0.031 | -0.001 | +0.002 [-0.003, +0.010] | 17 / 10 | — | no |
| 20 | -0.15 | 0.030 | +0.000 | +0.000 [-0.002, +0.002] | 9 / 2 | — | no |
| 20 | -0.1 | 0.031 | -0.001 | +0.001 [+0.000, +0.002] | 6 / 2 | — | no |
| 20 | +0.1 | 0.027 | +0.002 | -0.002 [-0.006, +0.000] | 6 / 3 | — | no |
| 20 | +0.15 | 0.027 | +0.002 | -0.002 [-0.006, +0.000] | 13 / 8 | — | no |
| 20 | +0.3 | 0.025 | +0.005 | -0.005 [-0.007, -0.002] | 33 / 13 | disambig_accuracy, unnecessary_unknown | no |
| 20 | +0.6 | 0.019 | +0.011 | -0.010 [-0.020, -0.001] | 60 / 29 | disambig_accuracy, unnecessary_unknown | no |

Direction check (diagnostic, not part of the verdict; contrast `stereotype`): at negative strengths the vector raised stereotyped answers more than random in 0 of 12 settings and lowered them more than random in 0. For the stereotype contrast, negative strengths push toward the stereotype.

Cosine with the run 2 evidence direction from the same training rows: layer 8 -0.04, layer 13 +0.37, layer 20 -0.52. Near 1 would mean this vector is still mostly an abstention direction.

Validation only and exploratory: settings are not corrected for multiple comparisons, and there is one random direction per layer. A pass names a candidate for the full study, not a finding.
