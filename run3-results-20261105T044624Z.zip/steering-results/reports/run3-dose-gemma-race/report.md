# Steering under weight quantization

Split: **validation**. Config: `a9ca2e217da0d315`.

Synthetic smoke results validate plumbing only; real-model results require a GPU run.

| Precision | Source | Layer | Strength | Ambiguous acc. | Disambiguated acc. | Invalid |
|---|---|---:|---:|---:|---:|---:|
| bf16 | none | None | 0.0 | 0.904 | 0.809 | 0.000 |
| bf16 | prompt | None | 0.0 | 0.904 | 0.824 | 0.000 |
| bf16 | random | 12 | 0.1 | 0.909 | 0.807 | 0.000 |
| bf16 | random | 20 | 0.1 | 0.910 | 0.817 | 0.000 |
| bf16 | random | 12 | 0.6 | 0.904 | 0.809 | 0.000 |
| bf16 | random | 20 | 0.6 | 0.909 | 0.844 | 0.000 |
| bf16 | random | 12 | -0.15 | 0.904 | 0.811 | 0.000 |
| bf16 | random | 12 | 0.3 | 0.907 | 0.804 | 0.000 |
| bf16 | random | 28 | -0.15 | 0.911 | 0.809 | 0.000 |
| bf16 | random | 20 | -0.6 | 0.903 | 0.786 | 0.000 |
| bf16 | random | 28 | 0.6 | 0.903 | 0.809 | 0.000 |
| bf16 | random | 12 | -0.3 | 0.903 | 0.811 | 0.000 |
| bf16 | random | 28 | 0.1 | 0.904 | 0.807 | 0.000 |
| bf16 | random | 20 | -0.15 | 0.904 | 0.797 | 0.000 |
| bf16 | random | 12 | -0.1 | 0.904 | 0.809 | 0.000 |
| bf16 | random | 20 | 0.15 | 0.911 | 0.817 | 0.000 |
| bf16 | random | 28 | -0.1 | 0.910 | 0.807 | 0.000 |
| bf16 | random | 12 | 0.15 | 0.906 | 0.806 | 0.000 |
| bf16 | random | 20 | 0.3 | 0.913 | 0.830 | 0.000 |
| bf16 | random | 20 | -0.1 | 0.904 | 0.800 | 0.000 |
| bf16 | random | 28 | -0.3 | 0.913 | 0.809 | 0.000 |
| bf16 | random | 28 | -0.6 | 0.911 | 0.811 | 0.000 |
| bf16 | random | 12 | -0.6 | 0.900 | 0.819 | 0.000 |
| bf16 | random | 28 | 0.15 | 0.904 | 0.807 | 0.000 |
| bf16 | random | 28 | 0.3 | 0.903 | 0.807 | 0.000 |
| bf16 | random | 20 | -0.3 | 0.904 | 0.793 | 0.000 |
| bf16 | reference | 28 | -0.3 | 0.909 | 0.810 | 0.000 |
| bf16 | reference | 12 | -0.15 | 0.904 | 0.810 | 0.000 |
| bf16 | reference | 20 | 0.15 | 0.899 | 0.806 | 0.000 |
| bf16 | reference | 28 | -0.6 | 0.909 | 0.817 | 0.000 |
| bf16 | reference | 12 | -0.3 | 0.903 | 0.813 | 0.000 |
| bf16 | reference | 12 | 0.3 | 0.913 | 0.806 | 0.000 |
| bf16 | reference | 12 | 0.15 | 0.910 | 0.809 | 0.000 |
| bf16 | reference | 28 | 0.15 | 0.904 | 0.806 | 0.000 |
| bf16 | reference | 12 | 0.1 | 0.909 | 0.807 | 0.000 |
| bf16 | reference | 20 | -0.6 | 0.934 | 0.773 | 0.000 |
| bf16 | reference | 20 | 0.1 | 0.899 | 0.806 | 0.000 |
| bf16 | reference | 12 | -0.1 | 0.904 | 0.811 | 0.000 |
| bf16 | reference | 20 | -0.15 | 0.916 | 0.806 | 0.000 |
| bf16 | reference | 20 | 0.3 | 0.881 | 0.794 | 0.000 |
| bf16 | reference | 28 | 0.3 | 0.904 | 0.796 | 0.000 |
| bf16 | reference | 28 | 0.1 | 0.904 | 0.806 | 0.000 |
| bf16 | reference | 28 | -0.15 | 0.909 | 0.810 | 0.000 |
| bf16 | reference | 28 | -0.1 | 0.907 | 0.810 | 0.000 |
| bf16 | reference | 28 | 0.6 | 0.901 | 0.801 | 0.000 |
| bf16 | reference | 12 | 0.6 | 0.910 | 0.810 | 0.000 |
| bf16 | reference | 20 | -0.3 | 0.923 | 0.799 | 0.000 |
| bf16 | reference | 20 | 0.6 | 0.890 | 0.736 | 0.000 |
| bf16 | reference | 20 | -0.1 | 0.913 | 0.809 | 0.000 |
| bf16 | reference | 12 | -0.6 | 0.900 | 0.814 | 0.000 |

Paired 95% intervals resample whole scenario groups. Multiple strengths are exploratory; no multiplicity correction or equivalence claim is made.
See analysis.json for bias denominators, group-pair results, answer transitions, and paired intervals. Missing bias targets reduce annotation coverage; unknown and invalid outputs remain explicit.
