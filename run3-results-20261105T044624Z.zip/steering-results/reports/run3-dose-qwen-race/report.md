# Steering under weight quantization

Split: **validation**. Config: `1cdac5165f82dd80`.

Synthetic smoke results validate plumbing only; real-model results require a GPU run.

| Precision | Source | Layer | Strength | Ambiguous acc. | Disambiguated acc. | Invalid |
|---|---|---:|---:|---:|---:|---:|
| bf16 | none | None | 0.0 | 0.864 | 0.896 | 0.000 |
| bf16 | prompt | None | 0.0 | 0.886 | 0.881 | 0.000 |
| bf16 | random | 8 | 0.1 | 0.864 | 0.896 | 0.000 |
| bf16 | random | 13 | -0.3 | 0.864 | 0.897 | 0.000 |
| bf16 | random | 8 | 0.3 | 0.866 | 0.896 | 0.000 |
| bf16 | random | 13 | -0.15 | 0.861 | 0.896 | 0.000 |
| bf16 | random | 13 | 0.6 | 0.897 | 0.887 | 0.000 |
| bf16 | random | 20 | -0.6 | 0.861 | 0.896 | 0.000 |
| bf16 | random | 8 | 0.15 | 0.863 | 0.896 | 0.000 |
| bf16 | random | 8 | -0.3 | 0.869 | 0.896 | 0.000 |
| bf16 | random | 20 | 0.15 | 0.867 | 0.897 | 0.000 |
| bf16 | random | 20 | 0.6 | 0.866 | 0.887 | 0.000 |
| bf16 | random | 13 | 0.3 | 0.877 | 0.893 | 0.000 |
| bf16 | random | 20 | 0.1 | 0.867 | 0.897 | 0.000 |
| bf16 | random | 8 | -0.15 | 0.867 | 0.897 | 0.000 |
| bf16 | random | 13 | 0.15 | 0.871 | 0.894 | 0.000 |
| bf16 | random | 13 | -0.6 | 0.869 | 0.894 | 0.000 |
| bf16 | random | 8 | -0.6 | 0.873 | 0.896 | 0.000 |
| bf16 | random | 8 | -0.1 | 0.864 | 0.896 | 0.000 |
| bf16 | random | 8 | 0.6 | 0.870 | 0.893 | 0.000 |
| bf16 | random | 20 | -0.1 | 0.863 | 0.896 | 0.000 |
| bf16 | random | 20 | -0.15 | 0.863 | 0.894 | 0.000 |
| bf16 | random | 20 | 0.3 | 0.869 | 0.894 | 0.000 |
| bf16 | random | 13 | -0.1 | 0.861 | 0.897 | 0.000 |
| bf16 | random | 13 | 0.1 | 0.869 | 0.896 | 0.000 |
| bf16 | random | 20 | -0.3 | 0.861 | 0.896 | 0.000 |
| bf16 | reference | 13 | -0.1 | 0.866 | 0.897 | 0.000 |
| bf16 | reference | 8 | -0.1 | 0.866 | 0.897 | 0.000 |
| bf16 | reference | 8 | -0.3 | 0.871 | 0.899 | 0.000 |
| bf16 | reference | 20 | 0.15 | 0.866 | 0.894 | 0.000 |
| bf16 | reference | 13 | -0.6 | 0.897 | 0.900 | 0.000 |
| bf16 | reference | 8 | -0.6 | 0.877 | 0.897 | 0.000 |
| bf16 | reference | 8 | -0.15 | 0.867 | 0.897 | 0.000 |
| bf16 | reference | 20 | -0.3 | 0.867 | 0.896 | 0.000 |
| bf16 | reference | 13 | -0.3 | 0.876 | 0.899 | 0.000 |
| bf16 | reference | 20 | 0.6 | 0.883 | 0.890 | 0.000 |
| bf16 | reference | 20 | 0.1 | 0.864 | 0.894 | 0.000 |
| bf16 | reference | 20 | -0.15 | 0.866 | 0.896 | 0.000 |
| bf16 | reference | 13 | 0.15 | 0.871 | 0.897 | 0.000 |
| bf16 | reference | 8 | 0.6 | 0.867 | 0.894 | 0.000 |
| bf16 | reference | 20 | -0.1 | 0.864 | 0.897 | 0.000 |
| bf16 | reference | 8 | 0.1 | 0.864 | 0.896 | 0.000 |
| bf16 | reference | 8 | 0.15 | 0.864 | 0.896 | 0.000 |
| bf16 | reference | 20 | 0.3 | 0.871 | 0.896 | 0.000 |
| bf16 | reference | 20 | -0.6 | 0.873 | 0.891 | 0.000 |
| bf16 | reference | 13 | 0.3 | 0.870 | 0.894 | 0.000 |
| bf16 | reference | 13 | -0.15 | 0.869 | 0.899 | 0.000 |
| bf16 | reference | 13 | 0.1 | 0.867 | 0.897 | 0.000 |
| bf16 | reference | 8 | 0.3 | 0.866 | 0.897 | 0.000 |
| bf16 | reference | 13 | 0.6 | 0.879 | 0.889 | 0.000 |

Paired 95% intervals resample whole scenario groups. Multiple strengths are exploratory; no multiplicity correction or equivalence claim is made.
See analysis.json for bias denominators, group-pair results, answer transitions, and paired intervals. Missing bias targets reduce annotation coverage; unknown and invalid outputs remain explicit.
