# Dose check: google/gemma-2-9b-it

**Verdict: FAIL** (0 of 24 settings passed; rule in docs/dose-finding.md)

Unsteered baseline: stereotyped answers 0.019, ambiguous accuracy 0.992, disambiguated accuracy 0.837, unnecessary unknown 0.102, invalid 0.000, truncated 0.000.

| Layer | Strength | Stereotyped | Reduction | Bias vector minus random (95% CI) | Answers changed (vector / random) | Limits broken | Pass |
|---:|---:|---:|---:|---|---:|---|---|
| 12 | -0.6 | 0.018 | +0.002 | -0.008 [-0.021, -0.001] | 12 / 22 | — | no |
| 12 | -0.3 | 0.019 | +0.001 | -0.003 [-0.010, +0.001] | 5 / 12 | — | no |
| 12 | -0.15 | 0.019 | +0.001 | -0.002 [-0.007, +0.002] | 4 / 7 | — | no |
| 12 | -0.1 | 0.020 | -0.001 | +0.000 [-0.002, +0.002] | 3 / 5 | — | no |
| 12 | +0.1 | 0.020 | -0.001 | +0.002 [+0.000, +0.005] | 3 / 4 | — | no |
| 12 | +0.15 | 0.021 | -0.002 | +0.002 [+0.000, +0.007] | 3 / 4 | — | no |
| 12 | +0.3 | 0.022 | -0.002 | +0.005 [+0.000, +0.015] | 7 / 6 | — | no |
| 12 | +0.6 | 0.022 | -0.002 | +0.006 [+0.000, +0.017] | 8 / 11 | — | no |
| 20 | -0.6 | 0.019 | +0.001 | -0.003 [-0.021, +0.010] | 51 / 31 | disambig_accuracy, unnecessary_unknown | no |
| 20 | -0.3 | 0.021 | -0.002 | +0.004 [-0.002, +0.013] | 34 / 16 | disambig_accuracy, unnecessary_unknown | no |
| 20 | -0.15 | 0.023 | -0.003 | +0.005 [+0.001, +0.013] | 25 / 6 | disambig_accuracy | no |
| 20 | -0.1 | 0.022 | -0.002 | +0.002 [-0.002, +0.008] | 17 / 5 | — | no |
| 20 | +0.1 | 0.015 | +0.004 | -0.007 [-0.019, -0.001] | 17 / 8 | — | no |
| 20 | +0.15 | 0.015 | +0.004 | -0.007 [-0.021, +0.001] | 21 / 8 | — | no |
| 20 | +0.3 | 0.015 | +0.005 | -0.008 [-0.028, +0.007] | 38 / 13 | — | no |
| 20 | +0.6 | 0.023 | -0.003 | +0.001 [-0.037, +0.045] | 78 / 19 | ambig_accuracy, unnecessary_unknown | no |
| 28 | -0.6 | 0.015 | +0.005 | -0.007 [-0.018, +0.000] | 53 / 8 | ambig_accuracy, invalid | no |
| 28 | -0.3 | 0.021 | -0.002 | +0.001 [+0.000, +0.002] | 6 / 3 | — | no |
| 28 | -0.15 | 0.020 | -0.001 | +0.000 [+0.000, +0.000] | 2 / 3 | — | no |
| 28 | -0.1 | 0.020 | -0.001 | +0.000 [+0.000, +0.000] | 4 / 3 | — | no |
| 28 | +0.1 | 0.019 | +0.001 | -0.001 [-0.002, +0.000] | 3 / 3 | — | no |
| 28 | +0.15 | 0.019 | +0.001 | -0.001 [-0.002, +0.000] | 5 / 5 | — | no |
| 28 | +0.3 | 0.018 | +0.002 | -0.002 [-0.004, +0.000] | 7 / 7 | — | no |
| 28 | +0.6 | 0.015 | +0.004 | -0.005 [-0.011, +0.000] | 41 / 15 | disambig_accuracy, invalid, truncation | no |

Direction check (diagnostic, not part of the verdict; contrast `stereotype`): at negative strengths the vector raised stereotyped answers more than random in 1 of 12 settings and lowered them more than random in 1. For the stereotype contrast, negative strengths push toward the stereotype.

Cosine with the run 2 evidence direction from the same training rows: layer 12 -0.25, layer 20 -0.29, layer 28 -0.76. Near 1 would mean this vector is still mostly an abstention direction.

Validation only and exploratory: settings are not corrected for multiple comparisons, and there is one random direction per layer. A pass names a candidate for the full study, not a finding.
