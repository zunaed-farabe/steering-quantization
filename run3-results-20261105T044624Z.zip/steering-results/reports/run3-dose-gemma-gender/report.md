# Steering under weight quantization

Split: **validation**. Config: `bdadb7fcd2be17f3`.

Synthetic smoke results validate plumbing only; real-model results require a GPU run.

| Precision | Source | Layer | Strength | Ambiguous acc. | Disambiguated acc. | Invalid |
|---|---|---:|---:|---:|---:|---:|
| bf16 | none | None | 0.0 | 0.992 | 0.837 | 0.000 |
| bf16 | prompt | None | 0.0 | 0.998 | 0.827 | 0.001 |
| bf16 | random | 12 | -0.1 | 0.992 | 0.837 | 0.000 |
| bf16 | random | 12 | 0.3 | 0.992 | 0.839 | 0.000 |
| bf16 | random | 12 | 0.6 | 0.992 | 0.844 | 0.000 |
| bf16 | random | 12 | -0.6 | 0.990 | 0.842 | 0.000 |
| bf16 | random | 28 | -0.15 | 0.990 | 0.835 | 0.000 |
| bf16 | random | 20 | -0.3 | 0.989 | 0.829 | 0.000 |
| bf16 | random | 28 | -0.3 | 0.990 | 0.835 | 0.000 |
| bf16 | random | 20 | -0.1 | 0.992 | 0.832 | 0.000 |
| bf16 | random | 12 | -0.3 | 0.990 | 0.840 | 0.000 |
| bf16 | random | 12 | -0.15 | 0.990 | 0.839 | 0.000 |
| bf16 | random | 20 | 0.6 | 0.989 | 0.845 | 0.000 |
| bf16 | random | 20 | -0.6 | 0.979 | 0.827 | 0.000 |
| bf16 | random | 28 | -0.1 | 0.990 | 0.835 | 0.000 |
| bf16 | random | 20 | 0.3 | 0.990 | 0.848 | 0.000 |
| bf16 | random | 28 | 0.6 | 0.989 | 0.842 | 0.000 |
| bf16 | random | 28 | 0.3 | 0.992 | 0.839 | 0.000 |
| bf16 | random | 20 | 0.1 | 0.992 | 0.840 | 0.000 |
| bf16 | random | 28 | 0.15 | 0.992 | 0.839 | 0.000 |
| bf16 | random | 20 | 0.15 | 0.992 | 0.842 | 0.000 |
| bf16 | random | 12 | 0.15 | 0.992 | 0.837 | 0.000 |
| bf16 | random | 28 | 0.1 | 0.992 | 0.839 | 0.000 |
| bf16 | random | 12 | 0.1 | 0.992 | 0.837 | 0.000 |
| bf16 | random | 28 | -0.6 | 0.989 | 0.829 | 0.000 |
| bf16 | random | 20 | -0.15 | 0.992 | 0.832 | 0.000 |
| bf16 | reference | 20 | 0.6 | 0.947 | 0.840 | 0.001 |
| bf16 | reference | 12 | -0.15 | 0.992 | 0.842 | 0.000 |
| bf16 | reference | 28 | 0.1 | 0.992 | 0.835 | 0.000 |
| bf16 | reference | 20 | -0.1 | 0.992 | 0.826 | 0.000 |
| bf16 | reference | 12 | -0.3 | 0.992 | 0.840 | 0.000 |
| bf16 | reference | 20 | 0.15 | 0.989 | 0.855 | 0.000 |
| bf16 | reference | 20 | -0.3 | 0.992 | 0.802 | 0.000 |
| bf16 | reference | 20 | 0.3 | 0.982 | 0.860 | 0.001 |
| bf16 | reference | 12 | -0.6 | 0.992 | 0.852 | 0.000 |
| bf16 | reference | 28 | -0.3 | 0.990 | 0.839 | 0.000 |
| bf16 | reference | 12 | 0.15 | 0.992 | 0.835 | 0.000 |
| bf16 | reference | 12 | -0.1 | 0.992 | 0.837 | 0.000 |
| bf16 | reference | 20 | -0.15 | 0.992 | 0.815 | 0.000 |
| bf16 | reference | 28 | 0.15 | 0.992 | 0.832 | 0.000 |
| bf16 | reference | 12 | 0.1 | 0.992 | 0.834 | 0.000 |
| bf16 | reference | 28 | 0.6 | 0.997 | 0.782 | 0.023 |
| bf16 | reference | 28 | -0.6 | 0.955 | 0.837 | 0.039 |
| bf16 | reference | 20 | -0.6 | 0.994 | 0.773 | 0.000 |
| bf16 | reference | 20 | 0.1 | 0.990 | 0.853 | 0.000 |
| bf16 | reference | 12 | 0.3 | 0.992 | 0.835 | 0.000 |
| bf16 | reference | 12 | 0.6 | 0.992 | 0.839 | 0.000 |
| bf16 | reference | 28 | -0.15 | 0.990 | 0.837 | 0.000 |
| bf16 | reference | 28 | -0.1 | 0.990 | 0.837 | 0.000 |
| bf16 | reference | 28 | 0.3 | 0.994 | 0.831 | 0.000 |

Paired 95% intervals resample whole scenario groups. Multiple strengths are exploratory; no multiplicity correction or equivalence claim is made.
See analysis.json for bias denominators, group-pair results, answer transitions, and paired intervals. Missing bias targets reduce annotation coverage; unknown and invalid outputs remain explicit.
